const express = require('express');
const http = require('http');
const path = require('path');
const fs = require('fs');
const os = require('os');
const crypto = require('crypto');
const { Server } = require('socket.io');

const app = express();
const server = http.createServer(app);
const io = new Server(server, { maxHttpBufferSize: 15e6 });

// ---------- Storage (MongoDB, with JSON-file fallback) ----------
const store = require('./store');
const UPLOADS = path.join(__dirname, 'uploads');
fs.mkdirSync(UPLOADS, { recursive: true });
let db; // { users, groups, messages } loaded in start()

// ---------- Helpers ----------
const uid = () => crypto.randomBytes(8).toString('hex');
const hash = (pw, salt) => crypto.scryptSync(pw, salt, 32).toString('hex');
const online = new Map(); // username -> number of open sockets
const isOnline = (u) => (online.get(u) || 0) > 0;

// Conversation ids: "dm:alice|bob" (sorted) or "g:<groupId>"
function members(cid) {
  if (cid.startsWith('dm:')) return cid.slice(3).split('|');
  const g = db.groups[cid.slice(2)];
  return g ? g.members : [];
}
const receipt = (m) => ({ id: m.id, deliveredTo: m.deliveredTo, readBy: m.readBy });
function emitToMembers(cid, ev, payload) {
  members(cid).forEach((u) => io.to('u:' + u).emit(ev, payload));
}
function publicUsers() {
  const out = {};
  for (const [u, r] of Object.entries(db.users)) out[u] = { username: u, online: isOnline(u), lastSeen: r.lastSeen };
  return out;
}
function markDelivered(user) {
  const changes = {};
  const changed = [];
  for (const [cid, list] of Object.entries(db.messages)) {
    if (!members(cid).includes(user)) continue;
    for (const m of list) {
      if (m.type !== 'system' && m.from !== user && !m.deliveredTo.includes(user)) {
        m.deliveredTo.push(user);
        (changes[cid] = changes[cid] || []).push(receipt(m));
        changed.push(m);
      }
    }
  }
  for (const [cid, updates] of Object.entries(changes)) emitToMembers(cid, 'receipts', { convId: cid, updates });
  if (changed.length) store.saveMessages(changed);
}

// ---------- Static files ----------
app.use(express.static(path.join(__dirname, 'public')));
app.use('/uploads', (req, res, next) => { res.set('X-Content-Type-Options', 'nosniff'); next(); },
  express.static(UPLOADS));

const ALLOWED_EXT = ['.png', '.jpg', '.jpeg', '.gif', '.webp', '.mp3', '.wav', '.webm', '.ogg', '.m4a',
  '.mp4', '.pdf', '.txt', '.doc', '.docx', '.ppt', '.pptx', '.xls', '.xlsx', '.zip', '.csv'];

// ---------- Socket events ----------
io.on('connection', (socket) => {
  let me = null;

  // ----- Auth: register / login / token (auto-login) -----
  socket.on('auth', ({ mode, username, password, token } = {}, cb) => {
    if (typeof cb !== 'function') return;
    username = String(username || '').trim().toLowerCase();
    if (!/^[a-z0-9_.]{3,20}$/.test(username)) return cb({ error: 'Username: 3-20 letters, numbers, _ or .' });

    if (mode === 'token') {
      const r = db.users[username];
      if (!r || !token || r.token !== token) return cb({ error: 'Session expired' });
    } else {
      password = String(password || '');
      if (password.length < 4) return cb({ error: 'Password must be at least 4 characters' });
      if (mode === 'register') {
        if (db.users[username]) return cb({ error: 'Username already taken' });
        const salt = uid();
        db.users[username] = { salt, hash: hash(password, salt), token: uid() + uid(), lastSeen: Date.now() };
        store.saveUser(username, db.users[username]);
      } else {
        const r = db.users[username];
        if (!r || r.hash !== hash(password, r.salt)) return cb({ error: 'Wrong username or password' });
      }
    }

    me = username;
    socket.join('u:' + me);
    online.set(me, (online.get(me) || 0) + 1);
    markDelivered(me);

    const groups = {};
    const messages = {};
    for (const g of Object.values(db.groups)) if (g.members.includes(me)) groups[g.id] = g;
    for (const [cid, list] of Object.entries(db.messages)) {
      if (members(cid).includes(me)) messages[cid] = list.slice(-300);
    }
    cb({ ok: true, me, token: db.users[me].token, users: publicUsers(), groups, messages });
    io.emit('presence', { username: me, online: true, lastSeen: db.users[me].lastSeen });
  });

  // ----- Messaging -----
  socket.on('send', (d = {}) => {
    if (!me) return;
    const cid = String(d.convId || '');
    const mem = members(cid);
    if (!mem.includes(me)) return;
    if (cid.startsWith('dm:')) {
      const other = mem.find((u) => u !== me);
      if (!other || !db.users[other]) return;
    }
    const type = ['text', 'image', 'audio', 'file'].includes(d.type) ? d.type : 'text';
    const text = String(d.text || '').slice(0, 4000);
    const url = typeof d.url === 'string' && /^\/uploads\/[a-f0-9]+\.[a-z0-9]+$/.test(d.url) ? d.url : undefined;
    if (type === 'text' && !text.trim()) return;
    if (type !== 'text' && !url) return;

    const msg = {
      id: uid(), convId: cid, from: me, type, text, url,
      fileName: d.fileName ? String(d.fileName).slice(0, 100) : undefined,
      time: Date.now(), deliveredTo: [], readBy: [],
    };
    mem.forEach((u) => { if (u !== me && isOnline(u)) msg.deliveredTo.push(u); });
    (db.messages[cid] = db.messages[cid] || []).push(msg);
    store.saveMessages([msg]);
    emitToMembers(cid, 'message', msg);
  });

  socket.on('read', (cid) => {
    if (!me || typeof cid !== 'string' || !members(cid).includes(me)) return;
    const updates = [];
    const changed = [];
    for (const m of db.messages[cid] || []) {
      if (m.type !== 'system' && m.from !== me && !m.readBy.includes(me)) {
        m.readBy.push(me);
        if (!m.deliveredTo.includes(me)) m.deliveredTo.push(me);
        updates.push(receipt(m));
        changed.push(m);
      }
    }
    if (updates.length) { store.saveMessages(changed); emitToMembers(cid, 'receipts', { convId: cid, updates }); }
  });

  socket.on('typing', ({ convId, isTyping } = {}) => {
    if (!me || typeof convId !== 'string' || !members(convId).includes(me)) return;
    members(convId).filter((u) => u !== me)
      .forEach((u) => io.to('u:' + u).emit('typing', { convId, user: me, isTyping: !!isTyping }));
  });

  socket.on('delete', ({ convId, msgId } = {}) => {
    const m = (db.messages[convId] || []).find((x) => x.id === msgId);
    if (!me || !m || m.from !== me) return;
    m.deleted = true; m.text = ''; m.type = 'text';
    delete m.url; delete m.fileName;
    store.saveMessages([m]);
    emitToMembers(convId, 'message-update', m);
  });

  // ----- Groups -----
  socket.on('create-group', ({ name, members: list } = {}, cb) => {
    if (!me || typeof cb !== 'function') return;
    name = String(name || '').trim().slice(0, 30);
    const ms = [...new Set([me, ...(Array.isArray(list) ? list : []).filter((u) => db.users[u])])];
    if (!name || ms.length < 3) return cb({ error: 'Group needs a name and at least 2 other members' });
    const id = uid();
    db.groups[id] = { id, name, members: ms, admin: me, created: Date.now() };
    const sys = { id: uid(), convId: 'g:' + id, from: me, type: 'system',
      text: `${me} created group "${name}"`, time: Date.now(), deliveredTo: [], readBy: [] };
    db.messages['g:' + id] = [sys];
    store.saveGroup(db.groups[id]);
    store.saveMessages([sys]);
    ms.forEach((u) => io.to('u:' + u).emit('group', { group: db.groups[id], messages: [sys] }));
    cb({ ok: true, id });
  });

  // ----- File upload (images, voice notes, documents) -----
  socket.on('upload', ({ name, data } = {}, cb) => {
    if (typeof cb !== 'function') return;
    if (!me || !Buffer.isBuffer(data) || data.length > 12e6) return cb({ error: 'Invalid file' });
    let ext = path.extname(String(name || '')).toLowerCase();
    if (!ALLOWED_EXT.includes(ext)) ext = '.bin';
    const fname = uid() + ext;
    fs.writeFile(path.join(UPLOADS, fname), data, (err) =>
      cb(err ? { error: 'Upload failed' } : { url: '/uploads/' + fname }));
  });

  // ----- WebRTC signaling (audio / video calls) -----
  ['call-offer', 'call-answer', 'call-ice', 'call-reject', 'call-end'].forEach((ev) => {
    socket.on(ev, (payload = {}) => {
      const { to, ...rest } = payload;
      if (!me || !db.users[to]) return;
      io.to('u:' + to).emit(ev, { from: me, ...rest });
    });
  });

  // ----- Disconnect -----
  socket.on('disconnect', () => {
    if (!me) return;
    const n = (online.get(me) || 1) - 1;
    if (n <= 0) {
      online.delete(me);
      db.users[me].lastSeen = Date.now();
      store.saveUser(me, db.users[me]);
      io.emit('presence', { username: me, online: false, lastSeen: db.users[me].lastSeen });
    } else online.set(me, n);
  });
});

const PORT = process.env.PORT || 3000;
(async () => {
  db = await store.init();
  server.listen(PORT, () => {
    console.log(`\nLiveConnect running (${store.getMode() === 'mongodb' ? 'MongoDB' : 'JSON files'} storage):\n  Local:   http://localhost:${PORT}`);
    for (const list of Object.values(os.networkInterfaces()))
      for (const i of list) if (i.family === 'IPv4' && !i.internal) console.log(`  Network: http://${i.address}:${PORT}`);
    console.log('');
  });
})();
