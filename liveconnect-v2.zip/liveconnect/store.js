// Storage layer: MongoDB (via mongoose). If MongoDB is not reachable, falls back to local JSON files
// so the app still runs. All data is kept in memory for speed and written through to the database.
const fs = require('fs');
const path = require('path');

const DATA = path.join(__dirname, 'data');
let mode = 'json';
let models = null;
let jsonDb = null;
let timer;

// Connection string: env MONGO_URI > mongo-uri.txt > local MongoDB
function getUri() {
  if (process.env.MONGO_URI) return process.env.MONGO_URI.trim();
  try {
    const line = fs.readFileSync(path.join(__dirname, 'mongo-uri.txt'), 'utf8')
      .split(/\r?\n/).map((s) => s.trim()).find((l) => l && !l.startsWith('#'));
    if (line) return line;
  } catch { /* no file */ }
  return 'mongodb://127.0.0.1:27017/liveconnect';
}

function defineModels(mongoose) {
  const opt = { versionKey: false };
  return {
    User: mongoose.model('User', new mongoose.Schema({
      _id: String, salt: String, hash: String, token: String, lastSeen: Number,
    }, opt)),
    Group: mongoose.model('Group', new mongoose.Schema({
      _id: String, name: String, members: [String], admin: String, created: Number,
    }, opt)),
    Message: mongoose.model('Message', new mongoose.Schema({
      _id: String, convId: { type: String, index: true }, from: String, type: String, text: String,
      url: String, fileName: String, time: Number, deliveredTo: [String], readBy: [String], deleted: Boolean,
    }, opt)),
  };
}

function jsonLoad(f, def) {
  try { return JSON.parse(fs.readFileSync(path.join(DATA, f), 'utf8')); } catch { return def; }
}
function jsonSave() {
  clearTimeout(timer);
  timer = setTimeout(() => {
    fs.mkdirSync(DATA, { recursive: true });
    for (const k of Object.keys(jsonDb)) fs.writeFileSync(path.join(DATA, k + '.json'), JSON.stringify(jsonDb[k]));
  }, 300);
}

async function init() {
  const uri = getUri();
  try {
    const mongoose = require('mongoose');
    await mongoose.connect(uri, { serverSelectionTimeoutMS: 5000 });
    models = defineModels(mongoose);
    const [users, groups, msgs] = await Promise.all([
      models.User.find().lean(),
      models.Group.find().lean(),
      models.Message.find().sort({ time: 1 }).lean(),
    ]);
    const db = { users: {}, groups: {}, messages: {} };
    users.forEach((u) => { db.users[u._id] = { salt: u.salt, hash: u.hash, token: u.token, lastSeen: u.lastSeen }; });
    groups.forEach((g) => { db.groups[g._id] = { id: g._id, name: g.name, members: g.members, admin: g.admin, created: g.created }; });
    msgs.forEach((m) => {
      const { _id, __v, ...rest } = m;
      (db.messages[m.convId] = db.messages[m.convId] || []).push({ id: _id, ...rest });
    });
    mode = 'mongodb';
    const shown = uri.replace(/\/\/([^@/]+)@/, '//***@'); // hide password in logs
    console.log(`Database: MongoDB connected (${shown})`);
    return db;
  } catch (e) {
    console.log(`\n!! MongoDB not available (${e.message})`);
    console.log('!! Using local JSON files instead. Start MongoDB / fix mongo-uri.txt to use MongoDB.\n');
  }
  jsonDb = {
    users: jsonLoad('users.json', {}),
    groups: jsonLoad('groups.json', {}),
    messages: jsonLoad('messages.json', {}),
  };
  return jsonDb;
}

const logErr = (what) => (e) => console.error(`DB write failed (${what}):`, e.message);

function saveUser(name, rec) {
  if (mode !== 'mongodb') return jsonSave();
  models.User.updateOne({ _id: name },
    { $set: { salt: rec.salt, hash: rec.hash, token: rec.token, lastSeen: rec.lastSeen } },
    { upsert: true }).catch(logErr('user'));
}

function saveGroup(g) {
  if (mode !== 'mongodb') return jsonSave();
  models.Group.updateOne({ _id: g.id },
    { $set: { name: g.name, members: g.members, admin: g.admin, created: g.created } },
    { upsert: true }).catch(logErr('group'));
}

function saveMessages(list) {
  if (mode !== 'mongodb') return jsonSave();
  if (!list.length) return;
  const ops = list.map((m) => {
    const { id, ...rest } = m;
    const set = {}, unset = {};
    for (const [k, v] of Object.entries(rest)) { if (v === undefined) unset[k] = ''; else set[k] = v; }
    for (const k of ['url', 'fileName']) if (rest[k] === undefined) unset[k] = '';
    const update = { $set: set };
    if (Object.keys(unset).length) update.$unset = unset;
    return { updateOne: { filter: { _id: id }, update, upsert: true } };
  });
  models.Message.bulkWrite(ops).catch(logErr('messages'));
}

module.exports = { init, saveUser, saveGroup, saveMessages, getMode: () => mode };
