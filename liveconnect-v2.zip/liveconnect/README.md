# LiveConnect v2 – WhatsApp-style Real-Time Communication App

Node.js + Express + Socket.io + WebRTC + **MongoDB (mongoose)**.

If MongoDB is not running, the app automatically falls back to local JSON files (`data/`) so it still works. The terminal tells you which storage is active.

## Features
| Category | Features |
|---|---|
| Accounts | Register / login (hashed passwords), stay logged in after refresh |
| Chats | One-to-one chats with every registered user, group chats (create group, pick members) |
| Real-time | Instant messages, typing indicator, online / last seen, unread badges, notification sound |
| Message status | ✓ sent, ✓✓ delivered, blue ✓✓ read (works in groups too) |
| Media | Emoji picker, photo sharing, file sharing (PDF, docs, zip...), voice messages |
| Calls | Voice call and video call (WebRTC) with mute / camera off / end |
| Other | Delete own message, chat history saved, search chats, date separators, mobile responsive |

## Easiest way (Windows)
Extract the zip, open the folder and **double-click `start.bat`**. It installs packages, starts the server and opens the browser.

## Run on localhost (manual)
```bash
npm install
npm start
```
Open **http://localhost:3000**

## How to test (important)
You need two different users, so use **two different browsers** (e.g. Chrome + Edge) or one normal window + one **Incognito** window:
1. Window 1: Register as `arun`. Window 2: Register as `priya`.
2. Open each other's chat, send messages, photos, voice notes. Watch the ticks turn blue.
3. Click 📞 or 📹 to call. Allow camera/microphone.
4. Click 👥 to create a group (needs 3+ users: register a third user in another browser).

## Test on phone / other laptop
Both devices on the same WiFi. The terminal prints a `Network:` URL (e.g. http://192.168.1.5:3000).
Chat works there, but camera/mic need HTTPS on non-localhost. For calls on other devices use a free HTTPS tunnel:
```bash
npx ngrok http 3000
```
Share the https link ngrok prints. For a permanent link deploy on Render / Railway (build: `npm install`, start: `npm start`).

## MongoDB setup
**Option A – Local (recommended for college demo)**
1. Install *MongoDB Community Server* from mongodb.com/try/download/community (choose "Install as a Service").
2. That's it. The default connection `mongodb://127.0.0.1:27017/liveconnect` is already in `mongo-uri.txt`.
3. Run the app. Terminal shows `Database: MongoDB connected`.
4. To see the data: install *MongoDB Compass*, connect to `mongodb://127.0.0.1:27017`, open database `liveconnect` -> collections `users`, `groups`, `messages`.

**Option B – Cloud (MongoDB Atlas, free)**
1. Create a free cluster at mongodb.com/atlas, add a database user, and under Network Access allow your IP (or 0.0.0.0/0).
2. Click Connect -> Drivers -> copy the connection string.
3. Open `mongo-uri.txt`, replace the first line with that string (put `/liveconnect` before the `?`).

Collections: `users` (username, hashed password, token, lastSeen), `groups` (name, members, admin), `messages` (convId, from, type, text, url, time, deliveredTo, readBy).

## Structure
```
server.js          Express + Socket.io: auth, chat, groups, uploads, call signaling
store.js           MongoDB (mongoose) storage with JSON fallback
mongo-uri.txt      MongoDB connection string
public/index.html  UI layout
public/style.css   WhatsApp-style dark theme
public/app.js      Client logic
data/              created only when running in JSON fallback mode
uploads/           created automatically (shared files)
```
