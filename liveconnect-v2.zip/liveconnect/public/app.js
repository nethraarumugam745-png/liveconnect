const socket = io();
const $ = (id) => document.getElementById(id);
const S = { me: null, users: {}, groups: {}, msgs: {}, active: null, typing: {} };
let authMode = 'login';
let call = null, incoming = null, recorder = null, lastTypingSent = 0, stopTypingTimer = null;
const rtcCfg = { iceServers: [{ urls: 'stun:stun.l.google.com:19302' }] };

// ================= Helpers =================
function el(tag, cls, text) {
  const e = document.createElement(tag);
  if (cls) e.className = cls;
  if (text !== undefined) e.textContent = text;
  return e;
}
const dmId = (a, b) => 'dm:' + [a, b].sort().join('|');
const members = (cid) => cid.startsWith('dm:') ? cid.slice(3).split('|') : (S.groups[cid.slice(2)] || { members: [] }).members;
const other = (cid) => members(cid).find((u) => u !== S.me);
const convName = (cid) => cid.startsWith('dm:') ? other(cid) : (S.groups[cid.slice(2)] || {}).name || 'Group';
function colorOf(s) { let h = 0; for (const c of String(s)) h = (h * 31 + c.charCodeAt(0)) % 360; return `hsl(${h} 50% 42%)`; }
function avatar(name, isGroup, showDot) {
  const a = el('div', 'avatar', isGroup ? '👥' : String(name)[0].toUpperCase());
  a.style.background = colorOf(name);
  if (showDot && S.users[name] && S.users[name].online) a.appendChild(el('span', 'dot'));
  return a;
}
const fmtTime = (t) => new Date(t).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
function fmtDay(t) {
  const sod = (x) => new Date(x.getFullYear(), x.getMonth(), x.getDate()).getTime();
  const diff = Math.round((sod(new Date()) - sod(new Date(t))) / 864e5);
  if (diff === 0) return 'Today';
  if (diff === 1) return 'Yesterday';
  return new Date(t).toLocaleDateString([], { day: 'numeric', month: 'short', year: 'numeric' });
}
function lastSeenText(u) {
  if (!u || !u.lastSeen) return 'offline';
  const d = fmtDay(u.lastSeen);
  return 'last seen ' + (d === 'Today' ? 'today' : d.toLowerCase()) + ' at ' + fmtTime(u.lastSeen);
}
function toast(msg) {
  const t = $('toast');
  t.textContent = msg;
  t.classList.add('show');
  clearTimeout(toast.t);
  toast.t = setTimeout(() => t.classList.remove('show'), 2800);
}
function beep() {
  try {
    const c = new (window.AudioContext || window.webkitAudioContext)();
    const o = c.createOscillator(), g = c.createGain();
    o.connect(g); g.connect(c.destination);
    o.frequency.value = 880; g.gain.value = 0.05;
    o.start(); setTimeout(() => { o.stop(); c.close(); }, 120);
  } catch (e) { /* ignore */ }
}
const unreadCount = (cid) => (S.msgs[cid] || []).filter((m) => m.type !== 'system' && m.from !== S.me && !m.readBy.includes(S.me)).length;
function previewText(m) {
  if (!m) return '';
  if (m.deleted) return '🚫 Message deleted';
  const pre = m.from === S.me && m.type !== 'system' ? 'You: ' : '';
  if (m.type === 'image') return pre + '📷 Photo';
  if (m.type === 'audio') return pre + '🎤 Voice message';
  if (m.type === 'file') return pre + '📄 ' + (m.fileName || 'File');
  return pre + m.text;
}

// ================= Auth =================
function setMode(m) {
  authMode = m;
  $('tabLogin').classList.toggle('active', m === 'login');
  $('tabRegister').classList.toggle('active', m === 'register');
  $('authBtn').textContent = m === 'login' ? 'Log in' : 'Create account';
  $('authTitle').textContent = m === 'login' ? 'Welcome back' : 'Create your account';
  $('authError').textContent = '';
}
$('tabLogin').onclick = () => setMode('login');
$('tabRegister').onclick = () => setMode('register');
$('authBtn').onclick = submitAuth;
['username', 'password'].forEach((id) => $(id).addEventListener('keydown', (e) => { if (e.key === 'Enter') submitAuth(); }));

function submitAuth() {
  socket.emit('auth', { mode: authMode, username: $('username').value, password: $('password').value }, (res) => onAuth(res, false));
}
socket.on('connect', () => {
  const saved = JSON.parse(localStorage.getItem('lc') || 'null');
  if (saved) socket.emit('auth', { mode: 'token', username: saved.username, token: saved.token }, (res) => onAuth(res, true));
});
function onAuth(res, auto) {
  if (res.error) {
    if (auto) localStorage.removeItem('lc'); else $('authError').textContent = res.error;
    $('auth').classList.remove('hidden'); $('app').classList.add('hidden');
    return;
  }
  localStorage.setItem('lc', JSON.stringify({ username: res.me, token: res.token }));
  S.me = res.me; S.users = res.users; S.groups = res.groups; S.msgs = res.messages;
  $('meName').textContent = S.me;
  $('meAvatar').replaceChildren(avatar(S.me));
  $('auth').classList.add('hidden'); $('app').classList.remove('hidden');
  renderList();
  if (S.active && members(S.active).includes(S.me)) { renderHeader(); renderMessages(true); socket.emit('read', S.active); }
}
$('logoutBtn').onclick = () => { localStorage.removeItem('lc'); location.reload(); };

// ================= Chat list =================
function renderList() {
  const q = $('search').value.trim().toLowerCase();
  const cids = [
    ...Object.keys(S.users).filter((u) => u !== S.me).map((u) => dmId(S.me, u)),
    ...Object.keys(S.groups).map((id) => 'g:' + id),
  ];
  const info = cids.map((cid) => {
    const l = S.msgs[cid] || [];
    return { cid, name: convName(cid), last: l[l.length - 1], unread: unreadCount(cid) };
  }).filter((i) => i.name.toLowerCase().includes(q));
  info.sort((a, b) => (b.last ? b.last.time : 0) - (a.last ? a.last.time : 0) || a.name.localeCompare(b.name));

  const box = $('chatList');
  box.replaceChildren();
  const total = info.reduce((n, i) => n + i.unread, 0);
  const sections = [
    ['Groups', info.filter((i) => i.cid.startsWith('g:'))],
    ['Direct messages', info.filter((i) => i.cid.startsWith('dm:'))],
  ];
  sections.forEach(([title, list]) => {
    if (!list.length && q) return;
    box.appendChild(el('div', 'section', title));
    if (!list.length) box.appendChild(el('div', 'hint', 'No groups yet. Use + Group to create one.'));
    list.forEach((i) => {
      const isGroup = i.cid.startsWith('g:');
      const item = el('div', 'item' + (S.active === i.cid ? ' active' : ''));
      item.appendChild(avatar(i.name, isGroup, !isGroup));
      const mid = el('div', 'mid');
      mid.appendChild(el('div', 'name' + (i.unread ? ' strong' : ''), i.name));
      const typers = Object.keys(S.typing[i.cid] || {});
      mid.appendChild(el('div', 'prev' + (typers.length ? ' typing' : ''),
        typers.length ? 'typing…' : previewText(i.last) || (isGroup ? 'New group' : 'Say hello')));
      item.appendChild(mid);
      if (i.unread) item.appendChild(el('span', 'badge', String(i.unread)));
      item.onclick = () => openChat(i.cid);
      box.appendChild(item);
    });
  });
  document.title = (total ? `(${total}) ` : '') + 'LiveConnect';
}
$('search').oninput = renderList;

// ================= Open chat / header / messages =================
function openChat(cid) {
  S.active = cid;
  $('empty').classList.add('hidden');
  $('chatBox').classList.remove('hidden');
  $('app').classList.add('chat-open');
  $('emojiPanel').classList.add('hidden');
  renderHeader();
  renderMessages(true);
  socket.emit('read', cid);
  renderList();
  $('msgInput').focus();
}
$('backBtn').onclick = () => { S.active = null; $('app').classList.remove('chat-open'); renderList(); };

function renderHeader() {
  const cid = S.active;
  if (!cid) return;
  const isDm = cid.startsWith('dm:');
  $('chatName').textContent = convName(cid);
  $('chatAvatar').replaceChildren(avatar(convName(cid), !isDm, isDm));
  const typers = Object.keys(S.typing[cid] || {});
  let st;
  if (typers.length) st = isDm ? 'typing…' : typers.join(', ') + ' typing…';
  else if (isDm) { const u = S.users[other(cid)]; st = u && u.online ? 'online' : lastSeenText(u); }
  else st = members(cid).join(', ');
  $('chatStatus').textContent = st;
  $('chatStatus').classList.toggle('live', st === 'online' || st.endsWith('typing…'));
  $('audioCallBtn').classList.toggle('hidden', !isDm);
  $('videoCallBtn').classList.toggle('hidden', !isDm);
}

function statusInfo(m) {
  const others = members(m.convId).filter((u) => u !== S.me);
  const reads = others.filter((u) => m.readBy.includes(u)).length;
  const dels = others.filter((u) => m.deliveredTo.includes(u) || m.readBy.includes(u)).length;
  const group = m.convId.startsWith('g:');
  if (others.length && reads === others.length) return { t: group ? '✓✓ Seen by all' : '✓✓ Seen', cls: ' seen' };
  if (reads > 0) return { t: `✓✓ Seen by ${reads} of ${others.length}`, cls: ' seen' };
  if (others.length && dels === others.length) return { t: '✓✓ Delivered', cls: '' };
  return { t: '✓ Sent', cls: '' };
}

function renderMessages(stick) {
  const box = $('messages'), cid = S.active;
  if (!cid) return;
  const atBottom = stick || box.scrollHeight - box.scrollTop - box.clientHeight < 90;
  box.replaceChildren();
  let day = '', prev = null;
  (S.msgs[cid] || []).forEach((m) => {
    const d = fmtDay(m.time);
    if (d !== day) { day = d; prev = null; box.appendChild(el('div', 'day', d)); }
    if (m.type === 'system') { prev = null; box.appendChild(el('div', 'sys', m.text)); return; }
    const mine = m.from === S.me;
    const cont = prev && prev.from === m.from && m.time - prev.time < 5 * 60000;
    prev = m;

    const row = el('div', 'row' + (mine ? ' me' : '') + (cont ? ' cont' : ''));
    const gutter = el('div', 'gutter');
    if (cont) gutter.appendChild(el('span', 'hover-time', fmtTime(m.time)));
    else gutter.appendChild(avatar(m.from));
    const main = el('div', 'main');
    if (!cont) {
      const head = el('div', 'head');
      const who = el('span', 'who', mine ? 'You' : m.from);
      if (!mine) who.style.color = colorOf(m.from);
      head.append(who, el('span', 'when', fmtTime(m.time)));
      main.appendChild(head);
    }
    if (m.deleted) main.appendChild(el('div', 'deleted', 'This message was deleted'));
    else if (m.type === 'image') {
      const img = el('img', 'pic'); img.src = m.url; img.alt = 'Shared photo';
      img.onclick = () => window.open(m.url);
      img.onload = () => { if (atBottom) box.scrollTop = box.scrollHeight; };
      main.appendChild(img);
    } else if (m.type === 'audio') {
      const wrap = el('div', 'voice'); const a = el('audio'); a.controls = true; a.src = m.url;
      wrap.appendChild(a); main.appendChild(wrap);
    } else if (m.type === 'file') {
      const a = el('a', 'filecard'); a.href = m.url; a.target = '_blank'; a.download = m.fileName || '';
      a.append(el('span', '', '📄'), el('span', 'fname', m.fileName || 'file'), el('span', 'fdl', 'Download'));
      main.appendChild(a);
    } else main.appendChild(el('div', 'txt', m.text));

    if (mine && !m.deleted) {
      const st = statusInfo(m);
      main.appendChild(el('div', 'status' + st.cls, st.t));
    }
    row.append(gutter, main);
    if (mine && !m.deleted) {
      const act = el('div', 'actions'); const del = el('button', 'mini', 'Delete');
      del.onclick = () => socket.emit('delete', { convId: cid, msgId: m.id });
      act.appendChild(del); row.appendChild(act);
    }
    box.appendChild(row);
  });
  if (atBottom) box.scrollTop = box.scrollHeight;
}

// ================= Sending =================
const msgInput = $('msgInput');
function toggleSend() {
  $('sendBtn').disabled = msgInput.value.trim().length === 0;
}
function sendText() {
  const text = msgInput.value.trim();
  if (!text || !S.active) return;
  socket.emit('send', { convId: S.active, type: 'text', text });
  msgInput.value = '';
  toggleSend();
  clearTimeout(stopTypingTimer); lastTypingSent = 0;
  socket.emit('typing', { convId: S.active, isTyping: false });
}
$('sendBtn').onclick = sendText;
msgInput.addEventListener('keydown', (e) => { if (e.key === 'Enter') sendText(); });
msgInput.oninput = () => {
  toggleSend();
  if (!S.active) return;
  if (Date.now() - lastTypingSent > 2000) { lastTypingSent = Date.now(); socket.emit('typing', { convId: S.active, isTyping: true }); }
  clearTimeout(stopTypingTimer);
  const cid = S.active;
  stopTypingTimer = setTimeout(() => { lastTypingSent = 0; socket.emit('typing', { convId: cid, isTyping: false }); }, 1500);
};

// Emoji
const EMOJIS = '😀 😁 😂 🤣 😊 😍 😘 😎 🤔 😢 😭 😡 👍 👎 👏 🙏 💪 🔥 ✨ 🎉 ❤️ 💔 💯 🙌 😴 🤗 😅 😇 🥳 😜 🤝 👋 ✅ ❌ ⭐ 🎂 🍕 ☕ 📚 💻'.split(' ');
EMOJIS.forEach((e) => { const s = el('span', '', e); s.onclick = () => { msgInput.value += e; msgInput.focus(); toggleSend(); }; $('emojiPanel').appendChild(s); });
$('emojiBtn').onclick = () => $('emojiPanel').classList.toggle('hidden');

// Files / images
$('attachBtn').onclick = () => $('fileInput').click();
$('fileInput').onchange = (e) => {
  const f = e.target.files[0];
  if (f) sendFile(f, f.name, f.type.startsWith('image/') ? 'image' : f.type.startsWith('audio/') ? 'audio' : 'file');
  e.target.value = '';
};
async function sendFile(file, name, type) {
  if (!S.active) return;
  if (file.size > 12e6) return toast('File too large (max 12 MB)');
  const cid = S.active;
  toast('Uploading…');
  const buf = await file.arrayBuffer();
  socket.emit('upload', { name, data: buf }, (res) => {
    if (res.error) return toast(res.error);
    socket.emit('send', { convId: cid, type, url: res.url, fileName: name });
  });
}

// Voice message
$('micBtn').onclick = async () => {
  if (recorder) { recorder.stop(); return; }
  if (!S.active) return;
  try {
    const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
    const chunks = [];
    recorder = new MediaRecorder(stream);
    recorder.ondataavailable = (e) => chunks.push(e.data);
    recorder.onstop = () => {
      stream.getTracks().forEach((t) => t.stop());
      const blob = new Blob(chunks, { type: 'audio/webm' });
      recorder = null;
      $('micBtn').classList.remove('rec'); $('micBtn').textContent = '🎤 Voice note';
      msgInput.placeholder = 'Write a message';
      if (blob.size > 800) sendFile(blob, 'voice.webm', 'audio');
    };
    recorder.start();
    $('micBtn').classList.add('rec'); $('micBtn').textContent = '⏹ Stop and send';
    msgInput.placeholder = 'Recording… press Stop and send';
  } catch (e) { toast('Microphone not available: ' + e.message); }
};

// ================= Incoming socket events =================
socket.on('message', (m) => {
  (S.msgs[m.convId] = S.msgs[m.convId] || []).push(m);
  if (S.typing[m.convId]) { clearTimeout(S.typing[m.convId][m.from]); delete S.typing[m.convId][m.from]; }
  if (m.from !== S.me) {
    if (S.active === m.convId && document.visibilityState === 'visible') socket.emit('read', m.convId);
    else beep();
  }
  if (S.active === m.convId) { renderHeader(); renderMessages(m.from === S.me); }
  renderList();
});
socket.on('message-update', (m) => {
  const l = S.msgs[m.convId] || [];
  const i = l.findIndex((x) => x.id === m.id);
  if (i >= 0) l[i] = m;
  if (S.active === m.convId) renderMessages();
  renderList();
});
socket.on('receipts', ({ convId, updates }) => {
  const l = S.msgs[convId];
  if (!l) return;
  updates.forEach((u) => { const m = l.find((x) => x.id === u.id); if (m) { m.deliveredTo = u.deliveredTo; m.readBy = u.readBy; } });
  if (S.active === convId) renderMessages();
  renderList();
});
socket.on('typing', ({ convId, user, isTyping }) => {
  const t = (S.typing[convId] = S.typing[convId] || {});
  clearTimeout(t[user]);
  if (isTyping) t[user] = setTimeout(() => { delete t[user]; if (S.active === convId) renderHeader(); renderList(); }, 4000);
  else delete t[user];
  if (S.active === convId) renderHeader();
  renderList();
});
socket.on('presence', (p) => {
  S.users[p.username] = { ...(S.users[p.username] || {}), ...p };
  if (S.active && S.active.startsWith('dm:')) renderHeader();
  if (call && call.peer === p.username && !p.online) { toast(p.username + ' disconnected'); endCall(false); }
  renderList();
});
socket.on('group', ({ group, messages }) => {
  S.groups[group.id] = group;
  S.msgs['g:' + group.id] = messages;
  renderList();
  if (messages[0] && messages[0].from !== S.me) beep();
});
document.addEventListener('visibilitychange', () => {
  if (document.visibilityState === 'visible' && S.active) { socket.emit('read', S.active); }
});

// ================= Groups =================
$('newGroupBtn').onclick = () => {
  const list = $('groupMembers'); list.replaceChildren();
  Object.keys(S.users).filter((u) => u !== S.me).forEach((u) => {
    const label = el('label'); const cb = el('input'); cb.type = 'checkbox'; cb.value = u;
    label.append(cb, avatar(u), el('span', '', u)); list.appendChild(label);
  });
  $('groupName').value = ''; $('groupError').textContent = '';
  $('groupModal').classList.remove('hidden');
};
$('groupCancel').onclick = () => $('groupModal').classList.add('hidden');
$('groupCreate').onclick = () => {
  const ms = [...$('groupMembers').querySelectorAll('input:checked')].map((i) => i.value);
  socket.emit('create-group', { name: $('groupName').value, members: ms }, (res) => {
    if (res.error) { $('groupError').textContent = res.error; return; }
    $('groupModal').classList.add('hidden');
    openChat('g:' + res.id);
  });
};

// ================= Calls (WebRTC) =================
async function setupCall(peer, video) {
  const stream = await navigator.mediaDevices.getUserMedia({ audio: true, video });
  const pc = new RTCPeerConnection(rtcCfg);
  stream.getTracks().forEach((t) => pc.addTrack(t, stream));
  pc.ontrack = (e) => { $('remoteVideo').srcObject = e.streams[0]; $('callStatus').textContent = 'Connected'; };
  pc.onicecandidate = (e) => e.candidate && socket.emit('call-ice', { to: peer, candidate: e.candidate });
  pc.onconnectionstatechange = () => { if (pc.connectionState === 'failed') { toast('Call connection failed'); endCall(false); } };
  call = { peer, pc, stream, video, pending: [] };
  $('localVideo').srcObject = stream;
}
function showCall(status) {
  $('callOverlay').classList.remove('hidden');
  $('callOverlay').classList.toggle('audio', !call.video);
  $('callName').textContent = call.peer;
  $('callStatus').textContent = status;
  $('muteBtn').classList.remove('off'); $('camBtn').classList.remove('off');
  $('camBtn').classList.toggle('hidden', !call.video);
}
async function startCall(video) {
  const cid = S.active;
  if (!cid || !cid.startsWith('dm:')) return toast('Calls work in one-to-one chats');
  if (call || incoming) return toast('Already in a call');
  const peer = other(cid);
  if (!S.users[peer] || !S.users[peer].online) return toast(peer + ' is offline');
  try {
    await setupCall(peer, video);
    const offer = await call.pc.createOffer();
    await call.pc.setLocalDescription(offer);
    socket.emit('call-offer', { to: peer, offer, video });
    showCall('Calling…');
  } catch (e) {
    toast('Camera/mic error: ' + e.message + ' (needs localhost or HTTPS)');
    endCall(false);
  }
}
$('audioCallBtn').onclick = () => startCall(false);
$('videoCallBtn').onclick = () => startCall(true);

socket.on('call-offer', ({ from, offer, video }) => {
  if (call || incoming) return socket.emit('call-reject', { to: from, reason: 'busy' });
  incoming = { from, offer, video, pending: [] };
  $('incomingAvatar').replaceChildren(avatar(from));
  $('incomingName').textContent = from;
  $('incomingType').textContent = video ? 'Incoming video call…' : 'Incoming voice call…';
  $('incomingModal').classList.remove('hidden');
});
$('acceptBtn').onclick = async () => {
  const inc = incoming;
  incoming = null;
  $('incomingModal').classList.add('hidden');
  try {
    await setupCall(inc.from, inc.video);
    call.pending = inc.pending;
    await call.pc.setRemoteDescription(inc.offer);
    await flushCandidates();
    const answer = await call.pc.createAnswer();
    await call.pc.setLocalDescription(answer);
    socket.emit('call-answer', { to: inc.from, answer });
    showCall('Connecting…');
  } catch (e) {
    toast('Could not answer: ' + e.message);
    socket.emit('call-reject', { to: inc.from });
    endCall(false);
  }
};
$('rejectBtn').onclick = () => {
  if (incoming) socket.emit('call-reject', { to: incoming.from });
  incoming = null;
  $('incomingModal').classList.add('hidden');
};
socket.on('call-answer', async ({ from, answer }) => {
  if (!call || call.peer !== from) return;
  await call.pc.setRemoteDescription(answer);
  await flushCandidates();
});
socket.on('call-ice', async ({ from, candidate }) => {
  if (call && call.peer === from) {
    if (call.pc.remoteDescription) await call.pc.addIceCandidate(candidate).catch(() => {});
    else call.pending.push(candidate);
  } else if (incoming && incoming.from === from) incoming.pending.push(candidate);
});
async function flushCandidates() {
  for (const c of call.pending) await call.pc.addIceCandidate(c).catch(() => {});
  call.pending = [];
}
socket.on('call-reject', ({ from, reason }) => { toast(reason === 'busy' ? from + ' is busy' : from + ' declined the call'); endCall(false); });
socket.on('call-end', ({ from }) => {
  if (incoming && incoming.from === from) { incoming = null; $('incomingModal').classList.add('hidden'); toast('Missed call from ' + from); return; }
  if (call && call.peer === from) { toast('Call ended'); endCall(false); }
});
function endCall(notify = true) {
  if (call) {
    if (notify) socket.emit('call-end', { to: call.peer });
    call.pc.close();
    call.stream.getTracks().forEach((t) => t.stop());
    call = null;
  }
  $('remoteVideo').srcObject = null; $('localVideo').srcObject = null;
  $('callOverlay').classList.add('hidden');
}
$('endBtn').onclick = () => endCall(true);
$('muteBtn').onclick = (e) => {
  const t = call && call.stream.getAudioTracks()[0]; if (!t) return;
  t.enabled = !t.enabled; e.currentTarget.classList.toggle('off', !t.enabled);
};
$('camBtn').onclick = (e) => {
  const t = call && call.stream.getVideoTracks()[0]; if (!t) return;
  t.enabled = !t.enabled; e.currentTarget.classList.toggle('off', !t.enabled);
};
