@echo off
title LiveConnect Server
cd /d "%~dp0"

where node >nul 2>nul
if errorlevel 1 (
  echo Node.js is not installed. Install the LTS version from https://nodejs.org and run this file again.
  pause
  exit /b
)

if not exist node_modules (
  echo Installing packages, please wait...
  call npm install
)

echo Starting LiveConnect... browser will open automatically.
start "" cmd /c "timeout /t 4 >nul && start http://localhost:3000"
node server.js
pause
